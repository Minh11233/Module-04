package com.example.woodycoffee.Converter;

import com.example.woodycoffee.dto.BeverageDto;
import com.example.woodycoffee.model.beverage.Beverage;
import org.springframework.beans.BeanUtils;

public class BeverageConverter {
    public static BeverageDto convertToDto(Beverage beverage) {
        BeverageDto dto = new BeverageDto();
        BeanUtils.copyProperties(beverage, dto);
        return dto;
    }

    public static Beverage convertToEntity(BeverageDto dto) {
        Beverage beverage = new Beverage();
        BeanUtils.copyProperties(dto, beverage);
        return beverage;
    }
}
