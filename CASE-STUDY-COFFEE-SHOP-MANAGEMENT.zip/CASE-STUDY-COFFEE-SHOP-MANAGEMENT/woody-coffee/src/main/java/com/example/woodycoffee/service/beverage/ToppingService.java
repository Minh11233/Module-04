package com.example.woodycoffee.service.beverage;


import com.example.woodycoffee.model.beverage.Topping;

public interface ToppingService extends GeneralService<Topping>{
}
