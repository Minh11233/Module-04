package com.example.woodycoffee.repository.beverage;

import com.example.woodycoffee.model.beverage.Size;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SizeRepository extends PagingAndSortingRepository<Size, Long> {
}
