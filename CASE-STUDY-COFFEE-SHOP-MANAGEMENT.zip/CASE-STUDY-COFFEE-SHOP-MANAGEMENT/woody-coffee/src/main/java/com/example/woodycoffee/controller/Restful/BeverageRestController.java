package com.example.woodycoffee.controller.Restful;

import com.example.woodycoffee.dto.BeverageDto;
import com.example.woodycoffee.model.beverage.Beverage;
import com.example.woodycoffee.service.beverage.BeverageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/beverages")
public class BeverageRestController {
    private final BeverageService beverageService;
    public BeverageRestController(BeverageService beverageService) {
        this.beverageService = beverageService;
    }

    @GetMapping("list-beverage-dto")
    public ResponseEntity<?> findAllBevrageDto() {
        List<BeverageDto> beverageList = beverageService.findBeverageWithBeanUtils();
        if (beverageList.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(beverageList,HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Beverage> findBeverageById(@PathVariable Long id) {
        Optional<Beverage> beverageOptional = beverageService.findById(id);
        return (!beverageOptional.isPresent()) ? new ResponseEntity<>(HttpStatus.NOT_FOUND) : new ResponseEntity<>(beverageOptional.get(), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Beverage> saveBeverage(@RequestBody Beverage beverage) {
        return new ResponseEntity<>(beverageService.save(beverage), HttpStatus.CREATED);
    }

    @PutMapping("{id}")
    public ResponseEntity<Beverage> updateBeverage(@PathVariable Long id, @RequestBody Beverage beverage) {
        Optional<Beverage> existingBeverage = beverageService.findById(id);
        if (!existingBeverage.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        existingBeverage.get().setName(beverage.getName());
        return new ResponseEntity<>(beverageService.save(existingBeverage.get()), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Beverage> delete(@PathVariable Long id) {
        Optional<Beverage> beverageOptional = beverageService.findById(id);
        if (!beverageOptional.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        beverageService.remove(id);
        return new ResponseEntity<>(beverageService.save(beverageOptional.get()), HttpStatus.NO_CONTENT);

    }
}
