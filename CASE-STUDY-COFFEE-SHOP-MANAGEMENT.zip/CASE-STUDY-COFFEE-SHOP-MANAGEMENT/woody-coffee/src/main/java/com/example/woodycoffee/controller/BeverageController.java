package com.example.woodycoffee.controller;

import com.example.woodycoffee.Converter.BeverageConverter;
import com.example.woodycoffee.dto.BeverageDto;
import com.example.woodycoffee.model.beverage.*;
import com.example.woodycoffee.service.beverage.BeverageService;
import com.example.woodycoffee.service.beverage.GenreService;
import com.example.woodycoffee.service.beverage.SizeService;
import com.example.woodycoffee.service.beverage.ToppingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.io.File;
import java.util.Optional;

@Controller
//@RequestMapping("/beverage")
public class BeverageController {
    @Value("${file-upload}")
    private String fileUpload;
    @Autowired
    private BeverageService beverageService;
    @Autowired
    private GenreService genreService;
    @Autowired
    private SizeService sizeService;
    @Autowired
    private ToppingService toppingService;

    @ModelAttribute("genres")
    public Iterable<Genre> genres() {
        return genreService.findAll();
    }
    @ModelAttribute("toppings")
    public Iterable<Topping> toppings() {
        return toppingService.findAll();
    }
    @ModelAttribute("sizes")
    public Iterable<Size> sizes() {
        return sizeService.findAll();
    }
    @GetMapping("/maintain")
    public String goToMaintainingPage() {
        return "admin-view/maintain";
    }
    @PostMapping("/create-beverage")
    public ModelAndView saveBeverage(@ModelAttribute BeverageForm beverageForm) {
        MultipartFile imgFile = beverageForm.getImg();
        String fileName = imgFile.getOriginalFilename();
        try {
            FileCopyUtils.copy(beverageForm.getImg().getBytes(), new File(fileUpload + fileName));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        BeverageDto beverageDto = new BeverageDto(beverageForm.getId(), beverageForm.getPrice(), beverageForm.getName(), fileName,beverageForm.getGenre(),beverageForm.getSizeList(),beverageForm.getToppingList());
        Beverage beverage = BeverageConverter.convertToEntity(beverageDto);
        beverageService.save(beverage);
        return new ModelAndView("redirect:/beverages");
    }

    @GetMapping("/edit-beverage/{id}")
    public ModelAndView showEditForm(@PathVariable Long id) {
        Optional<Beverage> beverage = beverageService.findById(id);
        if (beverage.isPresent()) {
            ModelAndView modelAndView = new ModelAndView("/admin-view/edit");
            modelAndView.addObject("beverage", beverage.get());
            return modelAndView;
        } else {
            ModelAndView modelAndView = new ModelAndView("/error.404");
            return modelAndView;
        }
    }
    @PostMapping("/edit-beverage")
    public ModelAndView updateCustomer(@ModelAttribute("beverage") Beverage beverage) {
        beverageService.save(beverage);
        ModelAndView modelAndView = new ModelAndView("redirect:/beverages");
        modelAndView.addObject("beverage", beverage);
        modelAndView.addObject("message", "UPDATED SUCCESSFULLY");
        return modelAndView;
    }

    @GetMapping("/delete-beverage/{id}")
    public ModelAndView showDeleteForm(@PathVariable Long id) {
        Optional<Beverage> beverage = beverageService.findById(id);
        beverageService.remove(beverage.get().getId());
        return new ModelAndView("redirect:/beverages");
    }

    @GetMapping("/beverages")
    public ModelAndView listCustomers(@RequestParam("search") Optional<String> search,@PageableDefault(value = 5) Pageable pageable,
                                      @RequestParam(name = "sort", defaultValue = "name") String sortBy,
                                      @RequestParam(name = "direction", defaultValue = "ASC") String direction){
        Sort sortable = null;
        if (direction.equals("ASC")) {
            sortable = Sort.by(sortBy).ascending();
        }
        if (direction.equals("DESC")) {
            sortable = Sort.by(sortBy).descending();
        }
        pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sortable);
        Page<Beverage> beverageListForPaging;
        if(search.isPresent()){
            beverageListForPaging = beverageService.findBeveragesByNameContaining(search.get(), pageable);
        } else {
            beverageListForPaging = beverageService.findAll(pageable);
        }
        ModelAndView modelAndView = new ModelAndView("admin-view/home");
        modelAndView.addObject("beverageForm", new BeverageForm());
        modelAndView.addObject("beverageListForPaging", beverageListForPaging);
        return modelAndView;
    }

    @GetMapping("/beverages/view/{id}")
    public ModelAndView getBeverageInfo(@PathVariable Long id) {
        ModelAndView modelAndView = new ModelAndView("/checking");
        RestTemplate restTemplate = new RestTemplate();
        Beverage beverage = restTemplate.getForObject("http://localhost:8081/api/beverages/" + id, Beverage.class);
        modelAndView.addObject("beverage", beverage);
        return modelAndView;
    }

}
