package com.example.woodycoffee.service.user;

import com.example.woodycoffee.dto.RoleDto;

public interface RoleService extends GeneralService<RoleDto> {
}
