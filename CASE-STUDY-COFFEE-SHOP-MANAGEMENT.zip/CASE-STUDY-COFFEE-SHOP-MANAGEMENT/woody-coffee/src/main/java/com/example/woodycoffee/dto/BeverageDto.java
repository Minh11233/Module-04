package com.example.woodycoffee.dto;

import com.example.woodycoffee.model.beverage.Genre;
import com.example.woodycoffee.model.beverage.Size;
import com.example.woodycoffee.model.beverage.Topping;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BeverageDto {
    private Long id;
    private Long price;
    private String name;
    private String img;
    private Genre genre;
    private List<Size> sizeList;
    private List<Topping> toppingList;
}
