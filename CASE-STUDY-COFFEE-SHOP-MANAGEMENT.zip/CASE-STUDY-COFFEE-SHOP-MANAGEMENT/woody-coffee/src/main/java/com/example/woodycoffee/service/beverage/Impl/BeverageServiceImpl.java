package com.example.woodycoffee.service.beverage.Impl;


import com.example.woodycoffee.dto.BeverageDto;
import com.example.woodycoffee.model.beverage.Beverage;
import com.example.woodycoffee.repository.beverage.BeverageRepository;
import com.example.woodycoffee.service.beverage.BeverageService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BeverageServiceImpl implements BeverageService {
    @Autowired
    BeverageRepository beverageRepository;
    @Override
    public Iterable findAll() {
        return beverageRepository.findAll();
    }

    @Override
    public Optional<Beverage> findById(Long id) {

        return beverageRepository.findById(id);
    }
    @Override
    public Beverage save(Beverage beverage) {
        beverage.setActive(true);
        return beverageRepository.save(beverage);
    }

    @Override
    public void remove(Long id) {
        beverageRepository.deleteById(id);
    }

    @Override
    public Page<Beverage> findAll(Pageable pageable) {
        return beverageRepository.findAll(pageable);
    }

    @Override
    public Page<Beverage> findBeveragesByNameContaining(String name, Pageable pageable) {
        return beverageRepository.findBeveragesByNameContaining(name, pageable);
    }

    @Override
    public List<BeverageDto> findBeverageWithBeanUtils() {
        return beverageRepository.findAll()
                .stream()
                .map(entity -> {
                    BeverageDto dto = new BeverageDto();
                    BeanUtils.copyProperties(entity, dto);
                    return dto;
                })
                .collect(Collectors.toList());
    }
}
