package com.example.woodycoffee.model.beverage;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Beverage {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private Long price;
    private String name;
    private String img;
    @Column(name = "is_active", columnDefinition = "BIT DEFAULT 1")
    private boolean isActive;
    @ManyToOne
    @JoinColumn(name = "genre_id")
    private Genre genre;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "beverage_size", joinColumns = @JoinColumn(name = "beverage_id"), inverseJoinColumns = @JoinColumn(name = "size_id"))
    private List<Size> sizeList;


    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "beverage_topping", joinColumns = @JoinColumn(name = "beverage_id"), inverseJoinColumns = @JoinColumn(name = "topping_id"))
    private List<Topping> toppingList;
}
