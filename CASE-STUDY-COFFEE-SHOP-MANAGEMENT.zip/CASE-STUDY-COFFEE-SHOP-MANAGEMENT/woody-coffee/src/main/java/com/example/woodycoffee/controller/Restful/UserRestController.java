//package com.example.woodycoffee.controller.Restful;
//
//
//import com.example.woodycoffee.dto.UserDto;
//import com.example.woodycoffee.model.user.User;
//import com.example.woodycoffee.service.user.UserService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Optional;
//
//@RestController
//@RequestMapping("/api/users")
//public class UserRestController {
//
//    @Autowired
//    private UserService userService;
//
//    @GetMapping("/list-dto-with-model-mapper")
//    public ResponseEntity<?> findAllCustomersDtoWithModelMapper() {
//        List<UserDto> customers = null;
//        if (customers.isEmpty()) {
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//        return new ResponseEntity<>(customers, HttpStatus.OK);
//    }
//
//    @GetMapping("/{id}")
//    public ResponseEntity<User> findUserById(PathVariable Long id) {
//        Optional<User> userOptional = userService.findById(id);
//        return (!userOptional.isPresent())
//                ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
//                : new ResponseEntity<>(userOptional.get(), HttpStatus.OK);
//    }
//
//    @PostMapping
//    public ResponseEntity<User> saveCustomer(@RequestBody User user) {
//        return new ResponseEntity<>(userService.save(user), HttpStatus.CREATED);
//    }
//
//    @PutMapping("/{id}")
//    public ResponseEntity<User> updateCustomer(@PathVariable Long id, @RequestBody User user) {
//        Optional<User> existingUser = userService.findById(id);
//        if (!existingUser.isPresent()) {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//        existingUser.get().setFullName();
//        return new ResponseEntity<>(customerService.save(existingCustomer.get()), HttpStatus.OK);
//    }
//}
