package com.example.woodycoffee.repository.beverage;

import com.example.woodycoffee.model.beverage.Topping;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ToppingRepository extends PagingAndSortingRepository<Topping, Long> {
}
