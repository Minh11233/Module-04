package com.example.woodycoffee.service.beverage.Impl;

import com.example.woodycoffee.model.beverage.Genre;
import com.example.woodycoffee.repository.beverage.GenreRepository;
import com.example.woodycoffee.service.beverage.GenreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class GenreServiceImpl implements GenreService {
    @Autowired
    GenreRepository genreRepository;
    @Override
    public Iterable<Genre> findAll() {
        return genreRepository.findAll();
    }

    @Override
    public Optional<Genre> findById(Long id) {
        return genreRepository.findById(id);
    }

    @Override
    public Genre save(Genre genre) {
        return genreRepository.save(genre);
    }

    @Override
    public void remove(Long id) {
        genreRepository.deleteById(id);
    }
}
