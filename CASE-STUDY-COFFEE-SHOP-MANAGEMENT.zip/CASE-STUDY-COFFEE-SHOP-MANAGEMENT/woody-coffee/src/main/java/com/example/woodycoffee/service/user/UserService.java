package com.example.woodycoffee.service.user;


import com.example.woodycoffee.dto.RoleDto;
import com.example.woodycoffee.dto.UserDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService extends GeneralService<UserDto> {
    Iterable<UserDto> findAllByRole(RoleDto roleDto);
    Iterable<UserDto> findAll();
    Page<UserDto> findAll(Pageable pageable);
    Page<UserDto> findAllByFullNameContaining(String fullName, Pageable pageable);


    boolean isAuthenticated();
}
