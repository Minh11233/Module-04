package com.example.woodycoffee.service.beverage;

import com.example.woodycoffee.dto.BeverageDto;
import com.example.woodycoffee.model.beverage.Beverage;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BeverageService extends GeneralService<Beverage> {
    Page<Beverage> findAll(Pageable pageable);
    Page<Beverage> findBeveragesByNameContaining(String name, Pageable pageable);
    List<BeverageDto> findBeverageWithBeanUtils();

}
