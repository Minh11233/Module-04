package com.example.woodycoffee.repository.beverage;

import com.example.woodycoffee.model.beverage.Genre;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GenreRepository extends PagingAndSortingRepository<Genre, Long> {
}
