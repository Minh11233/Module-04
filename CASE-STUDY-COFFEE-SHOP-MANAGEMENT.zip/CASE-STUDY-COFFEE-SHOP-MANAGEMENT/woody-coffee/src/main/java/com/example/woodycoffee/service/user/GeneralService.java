package com.example.woodycoffee.service.user;

import com.example.woodycoffee.model.user.User;

import java.util.Optional;

public interface GeneralService<T> {
    Iterable<T> findAll();

    Optional<T> findById(Long id);

    void save(T t);

    void remove(Long id);
}
