package com.example.woodycoffee.service.beverage;


import com.example.woodycoffee.model.beverage.Size;

public interface SizeService extends GeneralService<Size> {
}
