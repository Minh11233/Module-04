package com.example.woodycoffee.service.beverage;


import com.example.woodycoffee.model.beverage.Genre;

public interface GenreService extends GeneralService<Genre>{
}
