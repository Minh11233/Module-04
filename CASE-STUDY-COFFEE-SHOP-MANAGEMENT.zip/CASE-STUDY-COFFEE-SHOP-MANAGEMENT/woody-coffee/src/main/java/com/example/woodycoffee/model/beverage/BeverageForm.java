package com.example.woodycoffee.model.beverage;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BeverageForm {
    private Long id;
    private Long price;
    private String name;
    private MultipartFile img;
    private Genre genre;
    private List<Size> sizeList;
    private List<Topping> toppingList;

}
