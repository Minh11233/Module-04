package com.example.woodycoffee.controller;

import com.example.woodycoffee.model.beverage.Beverage;
import com.example.woodycoffee.service.beverage.BeverageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AuthController {
    @Autowired
    private BeverageService beverageService;
    @GetMapping({"/", "/homepage"})
    public String showHomePage(Model model) {
        Iterable<Beverage> beverageList = beverageService.findAll();
        model.addAttribute("beverageList", beverageList);
        return "/homepage";
    }
    @GetMapping("/access-denied")
    public ModelAndView accessDenied() {
        ModelAndView modelAndView = new ModelAndView("/error-403");
        return modelAndView;
    }

    @GetMapping("/not-found")
    public ModelAndView notFound() {
        ModelAndView modelAndView = new ModelAndView("/error-404");
        return modelAndView;
    }
}
