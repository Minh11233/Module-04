package com.example.woodycoffee.service.beverage.Impl;

import com.example.woodycoffee.model.beverage.Topping;
import com.example.woodycoffee.repository.beverage.ToppingRepository;
import com.example.woodycoffee.service.beverage.ToppingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class ToppingServiceImpl implements ToppingService {
    @Autowired
    ToppingRepository toppingRepository;

    @Override
    public Iterable<Topping> findAll() {
        return toppingRepository.findAll();
    }

    @Override
    public Optional<Topping> findById(Long id) {
        return toppingRepository.findById(id);
    }

    @Override
    public Topping save(Topping topping) {
        return toppingRepository.save(topping);
    }

    @Override
    public void remove(Long id) {
        toppingRepository.deleteById(id);
    }
}
