CREATE DATABASE coffee_shop;
use coffee_shop;


create table genre
(
    id    bigint auto_increment
        primary key,
    genre varchar(255) null
);

create table beverage
(
    id        bigint auto_increment
        primary key,
    img       varchar(255)     null,
    is_active bit default b'1' null,
    name      varchar(255)     null,
    price     bigint           null,
    genre_id  bigint           null
);

create table genre_beverage_list
(
    genre_id         bigint not null,
    beverage_list_id bigint not null,
    constraint UK_bxk8c2jhg3cevsh1116q698a0
        unique (beverage_list_id)
);


create table size
(
    id   bigint auto_increment
        primary key,
    size varchar(255) null
);

create table topping
(
    id      bigint auto_increment
        primary key,
    topping varchar(255) null
);

create table beverage_size
(
    beverage_id bigint not null,
    size_id     bigint not null
);

create table beverage_topping
(
    beverage_id bigint not null,
    topping_id  bigint not null
);

create table roles
(
    id          bigint auto_increment
        primary key,
    description varchar(255) null,
    name        varchar(255) null
);

create table users
(
    id             bigint auto_increment
        primary key,
    activated      bit          null,
    address        varchar(255) null,
    avatar         varchar(255) null,
    email          varchar(255) null,
    fullname       varchar(255) null,
    password       varchar(255) null,
    phone          varchar(255) null,
    remember_token varchar(255) null,
    username       varchar(255) null,
    role_id        bigint       not null
);