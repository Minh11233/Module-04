package com.example.woodycoffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WoodyCoffeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
